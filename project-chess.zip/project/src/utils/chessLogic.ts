import { Piece, Position, Move } from '../types/chess';

export const isValidMove = (
  board: (Piece | null)[][],
  from: Position,
  to: Position,
  piece: Piece
): boolean => {
  // Basic move validation
  if (to.x < 0 || to.x > 7 || to.y < 0 || to.y > 7) return false;
  
  const targetPiece = board[to.y][to.x];
  if (targetPiece && targetPiece.color === piece.color) return false;

  switch (piece.type) {
    case 'pawn':
      return isValidPawnMove(board, from, to, piece.color);
    case 'rook':
      return isValidRookMove(board, from, to);
    case 'knight':
      return isValidKnightMove(from, to);
    case 'bishop':
      return isValidBishopMove(board, from, to);
    case 'queen':
      return isValidQueenMove(board, from, to);
    case 'king':
      return isValidKingMove(from, to);
    default:
      return false;
  }
};

const isValidPawnMove = (
  board: (Piece | null)[][],
  from: Position,
  to: Position,
  color: 'white' | 'black'
): boolean => {
  const direction = color === 'white' ? -1 : 1;
  const startRow = color === 'white' ? 6 : 1;

  // Basic one square move
  if (from.x === to.x && to.y === from.y + direction && !board[to.y][to.x]) {
    return true;
  }

  // Initial two square move
  if (
    from.x === to.x &&
    from.y === startRow &&
    to.y === from.y + 2 * direction &&
    !board[to.y][to.x] &&
    !board[from.y + direction][from.x]
  ) {
    return true;
  }

  // Capture moves
  if (
    Math.abs(to.x - from.x) === 1 &&
    to.y === from.y + direction &&
    board[to.y][to.x] &&
    board[to.y][to.x]?.color !== color
  ) {
    return true;
  }

  return false;
};

const isValidRookMove = (
  board: (Piece | null)[][],
  from: Position,
  to: Position
): boolean => {
  if (from.x !== to.x && from.y !== to.y) return false;

  const dx = Math.sign(to.x - from.x);
  const dy = Math.sign(to.y - from.y);

  let x = from.x + dx;
  let y = from.y + dy;

  while (x !== to.x || y !== to.y) {
    if (board[y][x]) return false;
    x += dx;
    y += dy;
  }

  return true;
};

const isValidKnightMove = (from: Position, to: Position): boolean => {
  const dx = Math.abs(to.x - from.x);
  const dy = Math.abs(to.y - from.y);
  return (dx === 2 && dy === 1) || (dx === 1 && dy === 2);
};

const isValidBishopMove = (
  board: (Piece | null)[][],
  from: Position,
  to: Position
): boolean => {
  if (Math.abs(to.x - from.x) !== Math.abs(to.y - from.y)) return false;

  const dx = Math.sign(to.x - from.x);
  const dy = Math.sign(to.y - from.y);

  let x = from.x + dx;
  let y = from.y + dy;

  while (x !== to.x && y !== to.y) {
    if (board[y][x]) return false;
    x += dx;
    y += dy;
  }

  return true;
};

const isValidQueenMove = (
  board: (Piece | null)[][],
  from: Position,
  to: Position
): boolean => {
  return isValidRookMove(board, from, to) || isValidBishopMove(board, from, to);
};

const isValidKingMove = (from: Position, to: Position): boolean => {
  return Math.abs(to.x - from.x) <= 1 && Math.abs(to.y - from.y) <= 1;
};