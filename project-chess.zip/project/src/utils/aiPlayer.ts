import { Piece, Position, Move } from '../types/chess';
import { isValidMove } from './chessLogic';

export const findBestMove = (board: (Piece | null)[][]): Move => {
  const allPossibleMoves = getAllPossibleMoves(board, 'black');
  
  // For now, just pick a random valid move
  const randomIndex = Math.floor(Math.random() * allPossibleMoves.length);
  return allPossibleMoves[randomIndex];
};

const getAllPossibleMoves = (board: (Piece | null)[][], color: 'black' | 'white'): Move[] => {
  const moves: Move[] = [];

  for (let y = 0; y < 8; y++) {
    for (let x = 0; x < 8; x++) {
      const piece = board[y][x];
      if (piece && piece.color === color) {
        // Check all possible destinations
        for (let destY = 0; destY < 8; destY++) {
          for (let destX = 0; destX < 8; destX++) {
            if (isValidMove(board, { x, y }, { x: destX, y: destY }, piece)) {
              moves.push({
                from: { x, y },
                to: { x: destX, y: destY }
              });
            }
          }
        }
      }
    }
  }

  return moves;
};