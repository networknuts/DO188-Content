import { Piece, Position, Move } from '../types/chess';

export const makeMove = (
  board: (Piece | null)[][],
  move: Move
): (Piece | null)[][] => {
  const newBoard = board.map(row => [...row]);
  const piece = newBoard[move.from.y][move.from.x];
  
  if (piece) {
    newBoard[move.to.y][move.to.x] = piece;
    newBoard[move.from.y][move.from.x] = null;
  }
  
  return newBoard;
};