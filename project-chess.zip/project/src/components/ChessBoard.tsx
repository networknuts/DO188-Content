import React, { useState, useEffect } from 'react';
import { Piece, Position, Move } from '../types/chess';
import { isValidMove } from '../utils/chessLogic';
import { findBestMove } from '../utils/aiPlayer';
import { makeMove } from '../utils/gameState';
import ChessPiece from './ChessPiece';

const initialBoard: (Piece | null)[][] = Array(8)
  .fill(null)
  .map(() => Array(8).fill(null));

// Set up initial pieces
const setupBoard = () => {
  // Set up pawns
  for (let i = 0; i < 8; i++) {
    initialBoard[1][i] = { type: 'pawn', color: 'black' };
    initialBoard[6][i] = { type: 'pawn', color: 'white' };
  }

  // Set up other pieces
  const pieces: ('rook' | 'knight' | 'bishop' | 'queen' | 'king')[] = [
    'rook',
    'knight',
    'bishop',
    'queen',
    'king',
    'bishop',
    'knight',
    'rook',
  ];

  pieces.forEach((piece, i) => {
    initialBoard[0][i] = { type: piece, color: 'black' };
    initialBoard[7][i] = { type: piece, color: 'white' };
  });
};

setupBoard();

const ChessBoard: React.FC = () => {
  const [board, setBoard] = useState<(Piece | null)[][]>(initialBoard);
  const [selectedPiece, setSelectedPiece] = useState<Position | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<'white' | 'black'>('white');
  const [isThinking, setIsThinking] = useState(false);

  useEffect(() => {
    if (currentPlayer === 'black') {
      setIsThinking(true);
      // Add a small delay to make the AI move feel more natural
      setTimeout(() => {
        const aiMove = findBestMove(board);
        const newBoard = makeMove(board, aiMove);
        setBoard(newBoard);
        setCurrentPlayer('white');
        setIsThinking(false);
      }, 500);
    }
  }, [currentPlayer, board]);

  const handleSquareClick = (x: number, y: number) => {
    if (currentPlayer === 'black' || isThinking) return; // Prevent moves during AI turn

    if (!selectedPiece) {
      const piece = board[y][x];
      if (piece && piece.color === 'white') {
        setSelectedPiece({ x, y });
      }
    } else {
      const piece = board[selectedPiece.y][selectedPiece.x];
      if (piece && isValidMove(board, selectedPiece, { x, y }, piece)) {
        const newBoard = makeMove(board, {
          from: selectedPiece,
          to: { x, y }
        });
        setBoard(newBoard);
        setCurrentPlayer('black');
      }
      setSelectedPiece(null);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold mb-8">Chess Game</h1>
      <div className="bg-white p-4 rounded-lg shadow-lg">
        <div className="grid grid-cols-8 gap-0">
          {board.map((row, y) =>
            row.map((piece, x) => (
              <div
                key={`${x}-${y}`}
                className={`
                  w-16 h-16 flex items-center justify-center
                  ${(x + y) % 2 === 0 ? 'bg-amber-100' : 'bg-amber-800'}
                  ${
                    selectedPiece?.x === x && selectedPiece?.y === y
                      ? 'ring-2 ring-blue-500'
                      : ''
                  }
                  ${isThinking ? 'cursor-not-allowed' : 'cursor-pointer'}
                `}
                onClick={() => handleSquareClick(x, y)}
              >
                {piece && <ChessPiece piece={piece} />}
              </div>
            ))
          )}
        </div>
      </div>
      <div className="mt-4 text-lg font-semibold">
        {isThinking ? (
          <span className="text-gray-600">AI is thinking...</span>
        ) : (
          <span>Current Player: {currentPlayer}</span>
        )}
      </div>
    </div>
  );
};

export default ChessBoard;