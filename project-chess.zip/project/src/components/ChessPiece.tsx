import React from 'react';
import { Piece } from '../types/chess';
import {
  Crown,
  Sword,
  Cross,
  Building2,
  CircleDot,
  ChevronUp
} from 'lucide-react';

interface ChessPieceProps {
  piece: Piece;
}

const ChessPiece: React.FC<ChessPieceProps> = ({ piece }) => {
  const getPieceIcon = () => {
    switch (piece.type) {
      case 'king':
        return <Crown className="w-8 h-8" />;
      case 'queen':
        return <Cross className="w-8 h-8" />;
      case 'bishop':
        return <Sword className="w-8 h-8 rotate-45" />;
      case 'knight':
        return <CircleDot className="w-8 h-8" />;
      case 'rook':
        return <Building2 className="w-8 h-8" />;
      case 'pawn':
        return <ChevronUp className="w-8 h-8" />;
      default:
        return null;
    }
  };

  return (
    <div className={`${piece.color === 'white' ? 'text-white' : 'text-black'}`}>
      {getPieceIcon()}
    </div>
  );
};

export default ChessPiece;